# Animals
Have an array with animals; print it in the console. Use oop principles.
Home Work #1
Create a C# console application that iterates through an array of animals (at least three different animal types) and displays the following
message: "animal name" makes "animal sound".
*the project must compile
